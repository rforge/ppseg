matrice_H <- function(donnees,lambda,poids){
  TT <- length(donnees[1,])
  n <- length(donnees[,1]) 
  g <- length(lambda)
  H <- array(0,c(n,TT,g))
  for (i in 1:nrow(donnees)){
    tmp <- sapply(1:length(lambda), function(j) poids[,j] * dpois(donnees[i,], lambda[j]/TT))
    H[i,,] <- sweep(tmp, 1, rowSums(tmp), "/")
  }
  return(H)
}

estimation_max_lambda <- function(n,g,TT,donnees,H,w){
  lambda <- sapply(1:g,function(j) sum(sapply(1:TT,function(k) H[1:n,k,j]*donnees[1:n,k]*TT))/sum(sapply(1:TT,function(k) w[g*(k-1)+j])) )
  return(lambda)
}

log_vraisemblance_poids_2 <- function(betaVec,w,TT,g){
  res <- sum(sapply(1:TT,function(k){
    tmp_2 <- c(0,sapply(2:g, function(j) betaVec[j-1]+betaVec[(g-1)+(j-1)]*(k/TT)))
    m <- max(tmp_2)
    s1 <- sum(sapply(1:g,function(j) w[g*(k-1)+j]))
    sum(sapply(2:g,function(j) (betaVec[j-1]+betaVec[(g-1)+(j-1)]*(k/TT))*w[g*(k-1)+j])) - m*s1 -  s1*log(sum(sapply(1:g,function(j) exp(tmp_2[j]-m))))
  }))
  return(res)
}

grad_log_vraisemblance_poids_2 <- function(betaVec,w,TT,g){
  tmp_3 <- t(sapply(1:TT,function(k) c(0,sapply(2:g, function(jj) betaVec[jj-1]+betaVec[(g-1)+(jj-1)]*(k/TT)))))
  m <- sapply(1:TT,function(k) max(tmp_3[k,]))
  m_grad <- sapply(2:g,function(j){
    rowSums(sapply(1:TT,function(k){
      s1 <- tmp_3[k,j] - m[k] - log(sum(sapply(1:g,function(jj) exp(tmp_3[k,jj] - m[k]))))
      s2 <- sum(sapply(1:g,function(jj) w[g*(k-1)+jj]))
      c(w[g*(k-1)+j] - exp(s1)*s2,(k/TT)*(w[g*(k-1)+j] - exp(s1)*s2))
    }))
  }) 
  return(c(m_grad[1,],m_grad[2,]))
}

computeloglikelihood <- function(donnees, lambda, logpoids=ensemble_poids_3(beta, ncol(donnees)) )
  sum(sapply(1:nrow(donnees),
             function(i) 
               sum(sapply(1:ncol(donnees), 
                          function(k) logsum(sapply(1:length(lambda), 
                                                    function(j) logpoids[k,j] + dpois(donnees[i,k], lambda[j]/ncol(donnees), log=TRUE)))))))

EM <- function(donnees, g, nb_iteration_max=50, eps=2*10^-4){
  TT <- length(donnees[1,])          # T est le nombre d intervalles dans [0;1] 
  n <- length(donnees[,1])          # n est le nombre d individus 
  S <- data.frame(compo=as.factor(rep(1:g,TT)),time=rep((1:TT)/TT,each=g))
  # Initialisation des parametres \theta_0
  lambda <- 0.01 + sample((TT*min(donnees)):(TT*max(donnees)),g,replace=TRUE)
  beta <- rbind(c(0,0),matrix(runif(2*(g-1),-10,10),nrow=g-1,ncol=2))
  Log_vraisemblance_precedent <- -Inf
  logpoids <- ensemble_poids_3(beta, TT)
  Log_vraisemblance <- computeloglikelihood(donnees, lambda, logpoids)
  m <- 0                            # nombre d iterations
  while((m<nb_iteration_max)&((Log_vraisemblance - Log_vraisemblance_precedent)>eps)){
    m <- m + 1
    #                    Etape (E)                      #
    H <- matrice_H(donnees,lambda, exp(logpoids))
    w <- rowSums(sapply(1:(dim(H)[1]), function(i) as.numeric(t(H[i,,]))))
    #                    Etape (M)                      #
    lambda <- estimation_max_lambda(n, g, TT, donnees, H, w)
    beta <- createBeta(optim(createBetaVec(beta),
                             fn=log_vraisemblance_poids_2,
                             gr=grad_log_vraisemblance_poids_2,
                             w=w,
                             TT=TT,
                             g=g,
                             control=list(fnscale=-1),
                             method="L-BFGS-B" )$par)
    logpoids <- ensemble_poids_3(beta, TT)
    Log_vraisemblance_precedent <- Log_vraisemblance
    Log_vraisemblance <- computeloglikelihood(donnees, lambda, logpoids)
  }
  # *************************************************************** #
  return(list(poids=exp(logpoids),
              beta=beta,
              lambda=lambda,
              croissance_algo=(Log_vraisemblance_precedent<=Log_vraisemblance),
              nb_iteration=m,
              log_vraisemblance=Log_vraisemblance))
}


selection_EM <- function(donnees, g, nb_tests=4, nbcpu=3){
  res_EM <- NULL
  if (g>1){
    res_EM <- mclapply(1:nb_tests, function(i) EM(donnees,g), mc.silent=TRUE, mc.cores=nbcpu)
    res_EM <- res_EM[[which.max(sapply(1:nb_tests, function(i) res_EM[[i]]$log_vraisemblance))]]
  }else{
    TT <- length(donnees[1,])          # T est le nombre d intervalles dans [0;1] 
    n <- length(donnees[,1])          # n est le nombre d individus 
    lambda <- sum(donnees)/n
    Log_vraisemblance <- sum(sapply(1:n,function(i) sum(sapply(1:TT,function(k) log(dpois(donnees[i,k],lambda/TT))))))
    res_EM <- list(poids=1,beta=c(0,0),lambda=lambda,croissance_algo=TRUE,nb_iteration=1,log_vraisemblance=Log_vraisemblance)
  }
  return(res_EM)
}